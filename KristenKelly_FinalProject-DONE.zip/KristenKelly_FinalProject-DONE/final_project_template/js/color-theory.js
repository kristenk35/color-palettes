$(document).ready(function() {
  $('.slider-container').unslider({
    'arrows': false,
    'nav': false,
    'animation': 'vertical',
    'autoplay': true,
    'delay': 5000
  });
});


